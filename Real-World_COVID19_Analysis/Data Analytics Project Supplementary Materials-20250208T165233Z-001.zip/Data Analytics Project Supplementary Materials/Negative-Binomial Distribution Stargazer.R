library(dplyr)
library(openxlsx)
library(lubridate)
library(ggplot2)
library(MASS)
library(stargazer)

# Data Preparation
df_prepped <- Data %>%
  mutate(
    vax_group = ifelse(`Vaccination status` == "Unvaccinated",
                       "Unvaccinated",
                       "Vaccinated")
  )
View(df_prepped)

df_agg <- df_prepped %>%
  filter(`Cause of Death` == "All causes") %>%
  group_by(Yearmonth, `Age group`, vax_group) %>%
  summarize(
    deaths = sum(`Count of deaths`, na.rm = TRUE),
    Person_years = sum(`Person-years`, na.rm = TRUE)
  ) %>%
  ungroup()


# Split Data by Age Group
df_list <- split(df_agg, df_agg$`Age group`)


# Fit Negative Binomial Models for Each Age Group
model_list <- lapply(df_list, function(d) {
  glm.nb(
    deaths ~ vax_group + offset(log(Person_years)),
    data = d
  )
})

# Generate Results Table
stargazer(
  model_list,
  type = "text",
  title = "Negative Binomial Regression by Age Group",
  dep.var.labels = "Count of Deaths",
  column.labels = c("Age 18-39", "Age 40-49", "Age 50-59", "Age 60-69", "Age 70-79", "Age 80-89", "Age 90+"),
  covariate.labels = c("Vaccinated (vs. Unvaccinated)"),
  omit.stat = c("f", "ser", "adj.rsq")
)

# Exponentiate Coefficients for Rate Ratios
exp_coef <- lapply(model_list, function(m) exp(coef(m)["vax_groupVaccinated"]))
exp_coef  # Rate Ratio (RR) for Vaccinated vs. Unvaccinated
