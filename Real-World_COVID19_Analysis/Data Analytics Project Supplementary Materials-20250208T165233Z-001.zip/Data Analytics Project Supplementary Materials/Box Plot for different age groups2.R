# Assuming your dataset is called final_data
# and you have columns `Dose` and `RR` for each observation
library(ggplot2)
# 1. Make sure 'Dose' is a factor in the order you prefer
final_data2$Dose <- factor(final_data2$Dose, levels = unique(final_data$Dose))
View
# 2. Create a box plot
p <- ggplot(final_data2, aes(x = Dose, y = RR)) +
  geom_boxplot() +
  geom_hline(yintercept = 1, linetype = "dashed", color = "gray50") +  # Optional: reference line
  labs(
    title = "Box Plot of RRs by Dose Category (90+ Age Group)",
    x     = "Dose",
    y     = "Rate Ratio"
  ) +
  theme_minimal(base_size = 12) +
  theme(  # tilt x-axis labels if needed
    plot.title  = element_text(face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )
p

# 3. Save the box plot
ggsave(
  filename = "Boxplot_90+agegroups.png",
  plot = p,
  width = 10,
  height = 7,
  dpi = 300
)
