# Load required libraries
library(readxl)
library(dplyr)
library(tidyr)

# Step 1: Load the data
file_path <- "Supplementary Tables 15-21 (mortality non-Covid deaths).xlsx"
data <- read_excel(file_path, skip = 3, sheet = '90+')  # Skip the first three rows
colnames(data)[1] <- "Yearmonth"  # Rename the first column to "Yearmonth"

# Step 2: Group RR, Lower CI, and Upper CI into corresponding Dose categories
# Create dose labels based on RR column positions
dose_labels <- c(
  "1st_dose,<21_days",
  "1st_dose,≥21_days",
  "2nd_dose,<21_days",
  "2nd_dose,≥21_days",
  "3rd_dose,<21_days",
  "3rd_dose,≥21_days",
  "4th_dose,<21_days",
  "4th_dose,≥21_days"
)

# Assign column groups for RR, Lower CI, and Upper CI
grouped_data <- data %>%
  pivot_longer(
    cols = -Yearmonth,  # Exclude the Yearmonth column
    names_to = c("Metric", "Group"),
    names_pattern = "(RR)\\.{3}([0-9]+)",
    values_to = "Value"
  ) %>%
  mutate(
    Dose = rep(dose_labels, each = 3, length.out = n())
  ) %>%
  pivot_wider(
    names_from = Metric,
    values_from = Value
  )

# Step 3: Clean and format the data
final_data <- grouped_data %>%
  mutate(
    RR = as.numeric(gsub("\\*", "", RR)),  # Remove '*' and convert RR to numeric  # Convert Upper CI to numeric
  ) %>%
  select(Yearmonth, Dose, RR)  # Arrange columns for clarity

final_data2 <- final_data %>%
  select(Yearmonth,Dose,RR)%>%
  filter(!(is.na(RR)))


