library(dplyr)
library(openxlsx)
library(lubridate)
library(ggplot2)
library(MASS)
install.packages("stargazer")
library(stargazer)

df_prepped<- Data %>%
  mutate(
    vax_group=ifelse(`Vaccination status`=="Unvaccinated",
                     "Unvaccinated",
                     "Vaccinated")
  )
View(df_prepped) 
df_agg <- df_prepped %>%
  filter(`Cause of Death`=="All causes")%>%
  group_by(Yearmonth, `Age group`, vax_group)%>%
  summarize(deaths = sum(`Count of deaths`, na.rm = TRUE),
            Person_years = sum(`Person-years`, na.rm = TRUE))%>%
  ungroup()
View(df_agg)
df_list<- split(df_agg, df_agg$`Age group`)
View(df_list)
model_list<- lapply(df_list, function(d){
  glm(
    deaths~ vax_group + offset(log(Person_years)),
    family = poisson(link = "log"),
    data = d
  )
})
stargazer(
  model_list,
  type = "html",
  title = "Poisson Regression by Age Group",
  dep.var.labels = "Count of Deaths",
  column.labels = c("Age 18-39", "Age 40-49", "Age 50-59", "Age 60-69", "Age 70-79", "Age 80-89", "Age 90+"),
  covariate.labels = c("Vaccinated (vs. Unvaccinated)"),
  omit.stat = c("f", "ser", "adj.rsq"),
  out = "Poisson_output.html"
)
exp_coef <- lapply(model_list, function(m) exp(coef(m)["vax_groupVaccinated"]))
exp_coef  # This gives you the rate ratio for "Vaccinated" vs. "Unvaccinated."

summary(model_list[[1]])
