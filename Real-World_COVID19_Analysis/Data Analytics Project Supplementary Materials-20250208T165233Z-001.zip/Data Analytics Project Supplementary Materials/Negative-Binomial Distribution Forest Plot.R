library(ggplot2)
library(dplyr)

# Extract rate ratios and confidence intervals from the Negative Binomial models
rr_results <- lapply(model_list, function(m) {
  # Extract coefficients
  coef <- summary(m)$coefficients["vax_groupVaccinated", ]
  
  # Calculate RR and confidence intervals
  rr <- exp(coef["Estimate"])
  lower_ci <- exp(coef["Estimate"] - 1.96 * coef["Std. Error"])
  upper_ci <- exp(coef["Estimate"] + 1.96 * coef["Std. Error"])
  
  # Return results as a named vector
  c(RR = rr, Lower_CI = lower_ci, Upper_CI = upper_ci)
})

# Convert results into a data frame for plotting
rr_df <- do.call(rbind, rr_results) %>%
  as.data.frame() %>%
  mutate(Age_Group = names(model_list))

# Rename columns for clarity
colnames(rr_df) <- c("Rate_Ratio", "Lower_CI", "Upper_CI", "Age_Group")

# Plot the rate ratios as a forest plot
ggplot(rr_df, aes(x = Rate_Ratio, y = Age_Group)) +
  geom_point(size = 3) +  # Plot the rate ratios
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI), height = 0.2) +  # Add horizontal error bars
  geom_vline(xintercept = 1, color = "red", linetype = "dashed") +  # Reference line at RR = 1
  labs(
    title = "Vaccination Effect on Mortality by Age Group (Negative Binomial Models)",
    x = "Rate Ratio (Vaccinated vs. Unvaccinated)",
    y = "Age Group"
  ) +
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 12),
    axis.title = element_text(size = 14),
    plot.title = element_text(hjust = 0.5, size = 16)
  )

